package dev.seedcoordhud.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.server.integrated.IntegratedServer;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "render", at = @At("TAIL"))
    private void seedcoordhud$render(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) return;

        int left = 8;
        int top = 8;
        context.fill(left - 4, top - 4, left + 208, top + 43, 0xA0000000);
        context.drawText(client.textRenderer,
            Text.literal(String.format("XYZ: %.1f / %.1f / %.1f",
                client.player.getX(), client.player.getY(), client.player.getZ())),
            left, top, 0xFFFFFF, true);

        String seedText = "Seed: tidak tersedia di server publik";
        IntegratedServer server = client.getServer();
        if (server != null && server.getOverworld() != null) {
            seedText = "Seed: " + server.getOverworld().getSeed();
        }
        context.drawText(client.textRenderer, Text.literal(seedText),
            left, top + 15, 0x80E8FF, true);
        context.drawText(client.textRenderer,
            Text.literal("Seed multiplayer tidak dikirim ke client"),
            left, top + 29, 0xD0D0D0, true);
    }
}
