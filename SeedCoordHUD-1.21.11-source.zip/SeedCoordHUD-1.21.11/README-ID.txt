SEED & COORDINATES HUD — Minecraft Java 1.21.11 Fabric

FITUR
- Menampilkan koordinat X / Y / Z di kiri atas.
- Seed ditampilkan hanya jika tersedia dari Integrated Server (single-player/LAN host).
- Pada server publik, seed akan ditandai tidak tersedia. Mod ini tidak membobol proteksi server.

CATATAN
Ini adalah proyek SOURCE, bukan JAR yang sudah dikompilasi. Kode belum diuji build di lingkungan ini. Build memerlukan internet untuk mengunduh dependensi Gradle/Fabric/Minecraft.

CARA BUILD DI WINDOWS
1. Pasang Java JDK 21.
2. Buka folder proyek dengan IntelliJ IDEA sebagai proyek Gradle atau pasang Gradle.
3. Jalankan `gradle build` dari folder proyek.
4. Jika berhasil, JAR ada di `build/libs/`.
5. Masukkan JAR ke folder `mods` pada profil Minecraft 1.21.11 Fabric yang benar.

Seed server publik biasanya tidak dikirim ke client. Jadi mod client biasa tidak bisa menampilkan seed asli server multiplayer kecuali server/admin memang menyediakannya. Koordinat tetap tampil.
